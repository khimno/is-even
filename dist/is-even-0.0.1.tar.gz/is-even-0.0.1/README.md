# is-even

This is a simple library to check if an integer or string is an even number.
Credit to [marvinody](https://github.com/marvinody) for giving me this idea.
